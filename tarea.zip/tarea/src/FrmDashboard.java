import javax.swing.*;

public class FrmDashboard extends JFrame {
    private UsuarioService service;

    public FrmDashboard(UsuarioService service) {
        this.service = service;

        setTitle("Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Menú
        JMenuBar menuBar = new JMenuBar();

        JMenu menuUsuarios = new JMenu("Usuarios");
        JMenuItem itemRegistrarUsuario = new JMenuItem("Registrar Usuario");

        // Acción del submenú
        itemRegistrarUsuario.addActionListener(e -> {
            FrmRegistrarUsuario frmRegistrarUsuario = new FrmRegistrarUsuario(service);
            frmRegistrarUsuario.setVisible(true);
        });

        menuUsuarios.add(itemRegistrarUsuario);
        menuBar.add(menuUsuarios);

        setJMenuBar(menuBar);

        // Botón Cerrar Sesión
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.setBounds(150, 200, 130, 30);
        add(btnCerrarSesion);

        // Acción del botón Cerrar Sesión
        btnCerrarSesion.addActionListener(e -> {
            FrmLogin login = new FrmLogin(service); // Redirige al formulario de login
            login.setVisible(true);
            dispose(); // Cierra el formulario actual
        });
    }
}
