import javax.swing.*;

public class FrmLogin extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtClave;
    private JButton btnIngresar;
    private UsuarioService service;

    public FrmLogin(UsuarioService service) {
        this.service = service;

        // Configuración del formulario
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Componentes
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(20, 20, 80, 25);
        add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(100, 20, 160, 25);
        add(txtUsername);

        JLabel lblClave = new JLabel("Clave:");
        lblClave.setBounds(20, 60, 80, 25);
        add(lblClave);

        txtClave = new JPasswordField();
        txtClave.setBounds(100, 60, 160, 25);
        add(txtClave);

        btnIngresar = new JButton("Ingresar");
        btnIngresar.setBounds(100, 100, 100, 25);
        add(btnIngresar);

        // Acción del botón Ingresar
        btnIngresar.addActionListener(e -> {
            String username = txtUsername.getText();
            String clave = new String(txtClave.getPassword());

            if (service.validarUsuario(username, clave)) {
                JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso.");
                FrmDashboard dashboard = new FrmDashboard(service);
                dashboard.setVisible(true);
                dispose(); // Cierra el formulario actual
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o clave incorrectos.");
            }
        });
    }
}
