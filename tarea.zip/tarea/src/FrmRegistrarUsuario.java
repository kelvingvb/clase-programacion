import javax.swing.*;

public class FrmRegistrarUsuario extends JFrame {
    private JTextField txtNombre, txtEmail, txtUsername;
    private JPasswordField txtClave;
    private JButton btnGuardar, btnCancelar;
    private UsuarioService service;

    public FrmRegistrarUsuario(UsuarioService service) {
        this.service = service;

        // Configuración del formulario
        setTitle("Registrar Usuario");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Componentes
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 20, 80, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(100, 20, 160, 25);
        add(txtNombre);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(20, 60, 80, 25);
        add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(100, 60, 160, 25);
        add(txtEmail);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(20, 100, 80, 25);
        add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(100, 100, 160, 25);
        add(txtUsername);

        JLabel lblClave = new JLabel("Clave:");
        lblClave.setBounds(20, 140, 80, 25);
        add(lblClave);

        txtClave = new JPasswordField();
        txtClave.setBounds(100, 140, 160, 25);
        add(txtClave);

        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(20, 200, 100, 25);
        add(btnGuardar);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(140, 200, 100, 25);
        add(btnCancelar);

        // Acción del botón Guardar
        btnGuardar.addActionListener(e -> {
            String nombre = txtNombre.getText();
            String email = txtEmail.getText();
            String username = txtUsername.getText();
            String clave = new String(txtClave.getPassword());

            service.registrarUsuario(nombre, email, username, clave);
            JOptionPane.showMessageDialog(this, "Usuario registrado con éxito.");
            dispose(); // Cierra el formulario actual
        });

        // Acción del botón Cancelar
        btnCancelar.addActionListener(e -> dispose());
    }
}
