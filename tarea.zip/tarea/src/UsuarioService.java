import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioService {

    // Método para validar un usuario existente en el login
    public boolean validarUsuario(String username, String clave) {
        String sql = "SELECT * FROM usuarios WHERE username = ? AND clave = SHA2(?, 256)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            if (connection == null) {
                throw new SQLException("No se pudo establecer conexión a la base de datos.");
            }

            statement.setString(1, username);
            statement.setString(2, clave); // Encriptar y comparar con la base de datos
            ResultSet resultSet = statement.executeQuery();

            return resultSet.next(); // Retorna true si las credenciales coinciden

        } catch (SQLException e) {
            System.err.println("Error al validar el usuario: " + e.getMessage());
        }
        return false;
    }

    // Método para registrar un nuevo usuario
    public void registrarUsuario(String nombre, String email, String username, String clave) {
        String sql = "INSERT INTO usuarios (nombre, email, username, clave) VALUES (?, ?, ?, SHA2(?, 256))";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            if (connection == null) {
                throw new SQLException("No se pudo establecer conexión a la base de datos.");
            }

            statement.setString(1, nombre);
            statement.setString(2, email);
            statement.setString(3, username);
            statement.setString(4, clave); // La clave se encripta automáticamente
            statement.executeUpdate();

            System.out.println("Usuario registrado con éxito.");

        } catch (SQLException e) {
            System.err.println("Error al registrar el usuario: " + e.getMessage());
        }
    }
}
