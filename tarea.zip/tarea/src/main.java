public class main {
    public static void main(String[] args) {
        UsuarioService service = new UsuarioService();
        FrmLogin login = new FrmLogin(service);
        login.setVisible(true);
    }
}
